# 02 · Quiz — Pistas

## Pista 1 — Mostrar/ocultar pantallas
```js
function mostrarPantalla(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
}
```

## Pista 2 — Generar botones de opciones
```js
const letras = ['A','B','C','D'];
pregunta.opciones.forEach((texto, i) => {
  const btn = document.createElement('button');
  btn.className = 'option-btn';
  btn.innerHTML = `<span class="opt-letter">${letras[i]}</span>${texto}`;
  btn.addEventListener('click', () => seleccionarRespuesta(i));
  contenedor.appendChild(btn);
});
```

## Pista 3 — Barra de progreso
```js
const pct = ((index + 1) / preguntas.length) * 100;
document.getElementById('progress-bar').style.width = pct + '%';
```

## Pista 4 — Feedback visual
```js
const botones = document.querySelectorAll('.option-btn');
botones.forEach(b => b.disabled = true); // deshabilitar todos
botones[indiceOpcion].classList.add(esCorrecta ? 'correct' : 'wrong');
if (!esCorrecta) botones[pregunta.correcta].classList.add('correct');
```

## Pista 5 — Guardar respuesta para revisión
```js
respuestas.push({
  pregunta: pregunta.texto,
  elegida: indiceOpcion,
  correcta: pregunta.correcta,
  opciones: pregunta.opciones,
  acerto: indiceOpcion === pregunta.correcta
});
```

## Pista 6 — Fisher-Yates shuffle
```js
function mezclarArray(arr) {
  const a = [...arr]; // no mutar el original
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]]; // swap con destructuring
  }
  return a;
}
```
