// ════════════════════════════════════════════════
//  MINI PROYECTO 02 — Quiz de JavaScript
//  Tu trabajo: implementar toda la lógica de JS
// ════════════════════════════════════════════════

// ── 1. BANCO DE PREGUNTAS ────────────────────────
// El array de preguntas ya está aquí — no necesitas crearlo,
// pero léelo bien para entender la estructura.
const preguntas = [
  {
    categoria: "VARIABLES",
    texto: "¿Cuál de estas declaraciones produce un error si se usa antes de su línea de declaración?",
    opciones: ["var x = 1", "let x = 1", "function x(){}", "var x"],
    correcta: 1,
  },
  {
    categoria: "TIPOS",
    texto: "¿Qué retorna typeof null?",
    opciones: ["'null'", "'undefined'", "'object'", "'boolean'"],
    correcta: 2,
  },
  {
    categoria: "OPERADORES",
    texto: "¿Cuál es el resultado de 0 ?? 'default'?",
    opciones: ["'default'", "0", "null", "undefined"],
    correcta: 1,
  },
  {
    categoria: "ARRAYS",
    texto: "¿Qué método retorna un nuevo array sin modificar el original?",
    opciones: ["push()", "splice()", "map()", "sort()"],
    correcta: 2,
  },
  {
    categoria: "FUNCIONES",
    texto: "¿Cuál es la diferencia clave de una arrow function respecto a una function declaration?",
    opciones: [
      "No puede recibir parámetros",
      "No tiene su propio 'this'",
      "No puede retornar valores",
      "Solo acepta un parámetro"
    ],
    correcta: 1,
  },
  {
    categoria: "CLOSURES",
    texto: "¿Qué imprime este código?\n\nfor(var i=0; i<3; i++) { setTimeout(()=>console.log(i),0) }",
    opciones: ["0, 1, 2", "3, 3, 3", "0, 0, 0", "Error"],
    correcta: 1,
  },
  {
    categoria: "OBJETOS",
    texto: "¿Qué hace Object.freeze(obj)?",
    opciones: [
      "Elimina todas las propiedades",
      "Impide agregar y modificar propiedades",
      "Solo impide agregar propiedades nuevas",
      "Convierte el objeto en string"
    ],
    correcta: 1,
  },
  {
    categoria: "DOM",
    texto: "¿Cuál selector devuelve TODOS los elementos que coincidan?",
    opciones: [
      "document.querySelector()",
      "document.getElementById()",
      "document.querySelectorAll()",
      "document.getElement()"
    ],
    correcta: 2,
  },
  {
    categoria: "SCOPE",
    texto: "Una variable declarada con 'let' dentro de un bloque if {}...",
    opciones: [
      "Es accesible en todo el archivo",
      "Es accesible en toda la función",
      "Solo es accesible dentro del bloque",
      "Es accesible después del bloque"
    ],
    correcta: 2,
  },
  {
    categoria: "ARRAYS",
    texto: "¿Qué retorna [1,2,3].reduce((acc, x) => acc + x, 0)?",
    opciones: ["[1,2,3]", "6", "3", "undefined"],
    correcta: 1,
  },
];


// ── 2. ESTADO DEL JUEGO ──────────────────────────
// Define las variables que necesitas para rastrear el progreso

// TU CÓDIGO AQUÍ
// let preguntaActual = ...
// let puntaje        = ...
// let respuestas     = []   ← para la pantalla de revisión


// ── 3. SELECCIÓN DE ELEMENTOS ────────────────────
// Selecciona las pantallas y elementos interactivos

// TU CÓDIGO AQUÍ


// ── 4. FUNCIÓN: mostrarPantalla(id) ──────────────
// Oculta todas las pantallas y muestra la indicada
// Pista: usa la clase 'hidden'
function mostrarPantalla(id) {
  // TU CÓDIGO AQUÍ
}


// ── 5. FUNCIÓN: iniciarQuiz() ────────────────────
// Resetea el estado, mezcla las preguntas (opcional),
// muestra la primera pregunta
function iniciarQuiz() {
  // TU CÓDIGO AQUÍ
}


// ── 6. FUNCIÓN: mostrarPregunta(index) ───────────
// Renderiza la pregunta actual:
// - Actualiza barra de progreso (index+1 / total * 100%)
// - Actualiza contador "X / 10"
// - Actualiza categoría y texto de la pregunta
// - Genera los botones de opciones dinámicamente
// - Oculta el botón "Siguiente"
function mostrarPregunta(index) {
  // TU CÓDIGO AQUÍ
}


// ── 7. FUNCIÓN: generarOpciones(pregunta) ────────
// Crea los botones de opciones y los inserta en #q-options
// Cada botón debe tener: letra (A/B/C/D), texto de la opción
// Al hacer click → llamar a seleccionarRespuesta(indiceOpcion)
function generarOpciones(pregunta) {
  // TU CÓDIGO AQUÍ
  // Las letras: ['A','B','C','D']
}


// ── 8. FUNCIÓN: seleccionarRespuesta(indice) ─────
// Marca visualmente la respuesta elegida:
// - Si es correcta: clase 'correct' al botón
// - Si es incorrecta: clase 'wrong' al botón + mostrar cuál era la correcta
// - Deshabilita todos los botones
// - Actualiza puntaje si es correcta
// - Guarda en array de respuestas para la revisión
// - Muestra el botón "Siguiente"
function seleccionarRespuesta(indiceOpcion) {
  // TU CÓDIGO AQUÍ
}


// ── 9. FUNCIÓN: siguientePregunta() ──────────────
// Avanza al siguiente índice
// Si es la última pregunta → mostrarResultado()
// Si no → mostrarPregunta(siguiente)
function siguientePregunta() {
  // TU CÓDIGO AQUÍ
}


// ── 10. FUNCIÓN: mostrarResultado() ──────────────
// Calcula el resultado final y muestra la pantalla de resultados:
// - Emoji y mensaje según el puntaje (>8: 🏆, >5: 🎯, resto: 📚)
// - Muestra puntaje: X / 10
// - Desglose: correctas, incorrectas
function mostrarResultado() {
  // TU CÓDIGO AQUÍ
}


// ── 11. FUNCIÓN: mostrarRevision() ───────────────
// Genera la lista de revisión con cada pregunta:
// - Texto de la pregunta
// - Tu respuesta (verde si correcta, rojo si no)
// - La respuesta correcta (si fallaste)
function mostrarRevision() {
  // TU CÓDIGO AQUÍ
}


// ── 12. EVENT LISTENERS ──────────────────────────
// Conecta los botones de inicio, siguiente, reiniciar, revisión y volver

// TU CÓDIGO AQUÍ


// ── 13. BONUS: mezclar preguntas ─────────────────
// Implementa mezclarArray(arr) usando el algoritmo Fisher-Yates
// para que el orden sea aleatorio en cada partida
function mezclarArray(arr) {
  // TU CÓDIGO AQUÍ
}
