# 02 · Quiz de JavaScript

## ¿Qué construyes?
Un quiz interactivo con 10 preguntas sobre JS. Tiene 4 pantallas:
inicio → pregunta → resultado → revisión.

## Resultado esperado
- Pantalla de inicio con botón para empezar
- 10 preguntas con 4 opciones cada una
- Feedback inmediato al responder (verde/rojo)
- Barra de progreso que avanza con cada pregunta
- Pantalla de resultado con puntaje y desglose
- Pantalla de revisión con todas las respuestas

## Conceptos que practicas
- Arrays de objetos (banco de preguntas)
- Índices y recorrido de arrays
- Manipulación del DOM (crear elementos dinámicamente)
- Mostrar/ocultar elementos (clase 'hidden')
- Estado del juego con múltiples variables
- Condicionales para feedback y mensajes

## Criterios de éxito
- [ ] Las 4 pantallas funcionan y se transicionan correctamente
- [ ] La respuesta correcta siempre se muestra en verde
- [ ] Si eliges mal, tu respuesta queda en rojo Y la correcta en verde
- [ ] La barra de progreso llega al 100% en la última pregunta
- [ ] El puntaje es correcto
- [ ] La revisión muestra qué respondiste vs qué era correcto
- [ ] Bonus: las preguntas se mezclan en cada partida

## Archivos
- `index.html` — 4 pantallas ya estructuradas, no modificar
- `css/styles.css` — diseño terminado, no modificar
- `js/scripts.js` — **aquí trabajas tú** (las preguntas ya están)
- `hints.md` — pistas si te trabas
