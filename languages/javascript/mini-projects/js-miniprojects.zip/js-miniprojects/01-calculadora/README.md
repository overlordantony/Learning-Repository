# 01 · Calculadora

## ¿Qué construyes?
Una calculadora funcional con historial de operaciones y soporte para teclado físico.

## Resultado esperado
- Display que muestra el número actual y la expresión en curso
- Operaciones básicas: suma, resta, multiplicación, división
- Funciones: AC (limpiar), +/− (cambiar signo), % (porcentaje)
- Historial de las últimas operaciones (click en un item para reutilizar el resultado)
- Indicador visual del operador activo
- Flash en el display al presionar =

## Conceptos que practicas
- Variables y estado (múltiples variables que se coordinan)
- Operadores aritméticos y condicionales
- Manipulación del DOM
- Event delegation
- Manejo de casos límite (división por cero, números largos, múltiples decimales)

## Criterios de éxito
- [ ] Los 4 operadores funcionan correctamente
- [ ] AC reinicia todo el estado
- [ ] No se pueden ingresar dos puntos decimales en el mismo número
- [ ] División por cero muestra un mensaje de error (no rompe la app)
- [ ] El historial guarda las últimas 5 operaciones
- [ ] Al hacer click en el historial, el resultado se carga en el display
- [ ] Bonus: el teclado físico funciona

## Archivos
- `index.html` — estructura completa, no modificar
- `css/styles.css` — diseño terminado, no modificar
- `js/scripts.js` — **aquí trabajas tú**
- `hints.md` — pistas si te trabas
