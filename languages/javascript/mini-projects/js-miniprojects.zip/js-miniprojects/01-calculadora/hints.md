# 01 · Calculadora — Pistas

## El estado mínimo que necesitas
```js
let valorActual    = "0";   // string (para manipular dígitos fácilmente)
let valorAnterior  = null;  // número
let operador       = null;  // "+", "-", "*", "/"
let esperandoSegundoNumero = false;
let historial      = [];
```

## Pista 1 — Flujo de una operación
1. Usuario presiona `7` → agregarDigito("7") → display muestra "7"
2. Usuario presiona `+` → seleccionarOperador("+") → guarda 7 en valorAnterior, guarda operador
3. Usuario presiona `3` → agregarDigito("3") → display muestra "3"
4. Usuario presiona `=` → ejecutarIgual() → calcular(7, 3, "+") → display muestra "10"

## Pista 2 — Números como strings
Guarda el número actual como string para facilitar agregar dígitos:
```js
valorActual = valorActual + num; // "7" + "3" = "73"
```
Solo convierte a número cuando necesites calcular: `parseFloat(valorActual)`

## Pista 3 — Event delegation en el keypad
En vez de agregar un listener a cada botón, agrega uno al padre:
```js
document.querySelector('.keypad').addEventListener('click', (e) => {
  const btn = e.target.closest('.btn');
  if (!btn) return;
  const num    = btn.dataset.num;
  const op     = btn.dataset.op;
  const action = btn.dataset.action;
  // switch o if/else según qué tiene el botón
});
```

## Pista 4 — Resaltar operador activo
Al seleccionar un operador, agrega clase `.active` al botón correspondiente:
```js
// Quitar active de todos los operadores
document.querySelectorAll('.btn-op').forEach(b => b.classList.remove('active'));
// Agregar al actual
const btnOp = document.querySelector(`[data-op="${op}"]`);
if (btnOp) btnOp.classList.add('active');
```

## Pista 5 — Flash en el display
```js
display.classList.add('flash');
setTimeout(() => display.classList.remove('flash'), 200);
```

## Pista 6 — Teclado físico
```js
document.addEventListener('keydown', (e) => {
  if (e.key >= '0' && e.key <= '9') agregarDigito(e.key);
  if (['+','-','*','/'].includes(e.key)) seleccionarOperador(e.key);
  if (e.key === 'Enter' || e.key === '=') ejecutarIgual();
  if (e.key === 'Escape') limpiar();
  if (e.key === '.') agregarDecimal();
});
```

## Casos límite a considerar
- ¿Qué pasa si presionas `=` sin haber seleccionado operador?
- ¿Qué pasa si presionas un operador después de `=`? (debería continuar con el resultado)
- ¿Qué pasa con `0.1 + 0.2`? (floating point, usa `parseFloat(resultado.toFixed(10))`)
