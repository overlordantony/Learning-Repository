// ════════════════════════════════════════════════
//  MINI PROYECTO 01 — Calculadora
//  Tu trabajo: implementar toda la lógica de JS
//  El HTML y CSS ya están listos.
// ════════════════════════════════════════════════

// ── 1. SELECCIÓN DE ELEMENTOS ────────────────────
// Selecciona los elementos que necesitarás manipular
const display      = document.getElementById('display');
const expression   = document.getElementById('expression');
const historyList  = document.getElementById('history-list');
const calcMode     = document.getElementById('calc-mode');

// ── 2. ESTADO DE LA CALCULADORA ──────────────────
// Define las variables de estado que necesita la calculadora
// Piensa: ¿qué necesitas recordar entre pulsaciones?

// TU CÓDIGO AQUÍ
// let valorActual    = ...
// let valorAnterior  = ...
// let operador       = ...
// let esperandoSegundoNumero = ...
// let historial      = ...


// ── 3. FUNCIÓN: actualizar display ───────────────
// Actualiza el texto del display con el valor actual
// Maneja números largos (acortar si no caben)
function actualizarDisplay(valor) {
  // TU CÓDIGO AQUÍ
}


// ── 4. FUNCIÓN: agregar dígito ───────────────────
// Agrega un número al valor actual
// Casos a considerar:
// - Si estamos esperando el segundo número, reemplazar
// - No permitir múltiples ceros al inicio
// - Limitar la longitud del número
function agregarDigito(num) {
  // TU CÓDIGO AQUÍ
}


// ── 5. FUNCIÓN: agregar decimal ──────────────────
// Agrega punto decimal al número actual
// No permitir dos puntos decimales
function agregarDecimal() {
  // TU CÓDIGO AQUÍ
}


// ── 6. FUNCIÓN: seleccionar operador ─────────────
// Guarda el operador y el valor actual
// Actualiza la expresión visible arriba del display
// Resalta visualmente el botón del operador activo
function seleccionarOperador(op) {
  // TU CÓDIGO AQUÍ
}


// ── 7. FUNCIÓN: calcular ─────────────────────────
// Realiza la operación entre valorAnterior y valorActual
// Maneja el caso de división por cero
// Retorna el resultado
function calcular(a, b, op) {
  // TU CÓDIGO AQUÍ
  // switch(op) { case '+': ... }
}


// ── 8. FUNCIÓN: ejecutar igual ───────────────────
// Ejecuta el cálculo actual
// Agrega el resultado al historial
// Actualiza el display y la expresión
// Muestra animación flash en el display
function ejecutarIgual() {
  // TU CÓDIGO AQUÍ
}


// ── 9. FUNCIÓN: limpiar ──────────────────────────
// Resetea todo el estado al valor inicial
function limpiar() {
  // TU CÓDIGO AQUÍ
}


// ── 10. FUNCIÓN: toggle signo ────────────────────
// Cambia el signo del número actual (positivo ↔ negativo)
function toggleSigno() {
  // TU CÓDIGO AQUÍ
}


// ── 11. FUNCIÓN: porcentaje ──────────────────────
// Convierte el número actual a porcentaje (divide entre 100)
function calcularPorcentaje() {
  // TU CÓDIGO AQUÍ
}


// ── 12. FUNCIÓN: agregar al historial ────────────
// Crea un elemento en #history-list con la operación y resultado
// Formato: "3 + 4 = 7"
// Al hacer click en un item del historial, cargar ese resultado en el display
function agregarAlHistorial(expresionCompleta, resultado) {
  // TU CÓDIGO AQUÍ
}


// ── 13. EVENT LISTENERS ──────────────────────────
// Conecta todos los botones con sus funciones
// Usa delegación de eventos en el keypad

// Pista: el keypad tiene botones con distintos data-attributes:
//   data-num="7"         → agregarDigito
//   data-op="+"          → seleccionarOperador
//   data-action="clear"  → limpiar
//   data-action="equals" → ejecutarIgual
//   data-action="decimal"
//   data-action="toggle-sign"
//   data-action="percent"

// TU CÓDIGO AQUÍ


// ── 14. BONUS: teclado físico ────────────────────
// Opcional: agrega soporte para el teclado del computador
// Teclas: 0-9, +, -, *, /, Enter (=), Escape (AC), Backspace, .
// TU CÓDIGO AQUÍ (opcional)
