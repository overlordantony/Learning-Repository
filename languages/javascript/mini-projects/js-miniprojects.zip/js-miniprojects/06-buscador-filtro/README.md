# 06 · Buscador y Filtro de Devs

## ¿Qué construyes?
Un directorio de desarrolladores con búsqueda en tiempo real, filtros y ordenamiento.

## Resultado esperado
- Grid de cards con info de cada dev (nombre, rol, nivel, tecnologías, rating)
- Búsqueda que filtra por nombre, rol y tecnologías simultáneamente
- Las coincidencias de búsqueda se resaltan en amarillo
- Filtro por nivel (junior/mid/senior)
- Toggle para mostrar solo disponibles
- Ordenar por: nombre, experiencia o rating
- Contador de resultados en tiempo real

## Conceptos que practicas
- filter() con múltiples condiciones
- sort() con distintos criterios
- Generación dinámica de HTML (innerHTML con template literals)
- Eventos de formulario (input, change, click)
- Debounce para optimizar el input de búsqueda
- String.includes() e insensibilidad a mayúsculas

## Criterios de éxito
- [ ] La búsqueda funciona en tiempo real mientras escribes
- [ ] La búsqueda encuentra coincidencias en nombre, rol Y tecnologías
- [ ] Las coincidencias se resaltan visualmente
- [ ] Los filtros se pueden combinar (nivel + disponible + búsqueda)
- [ ] El ordenamiento funciona correctamente
- [ ] El contador muestra el número correcto de resultados
- [ ] Se muestra "∅ Sin resultados" cuando no hay coincidencias

## Archivos
- `js/scripts.js` — **aquí trabajas tú**
- `hints.md` — pistas si te trabas
