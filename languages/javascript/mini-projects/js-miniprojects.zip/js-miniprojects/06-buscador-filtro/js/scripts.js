// ════════════════════════════════════════════════
//  MINI PROYECTO 06 — Buscador y Filtro de Devs
// ════════════════════════════════════════════════

// ── 1. DATOS ─────────────────────────────────────
const devs = [
  { id:1, nombre:"Ana García",     rol:"Frontend Dev",   nivel:"senior", tech:["React","CSS","TypeScript"], exp:7, rating:4.9, disponible:true,  avatar:"👩‍💻" },
  { id:2, nombre:"Luis Morales",   rol:"Backend Dev",    nivel:"mid",    tech:["Node.js","Python","SQL"],   exp:4, rating:4.5, disponible:false, avatar:"👨‍💻" },
  { id:3, nombre:"Sara Kim",       rol:"Full Stack",     nivel:"senior", tech:["Vue","Go","Docker"],       exp:8, rating:4.8, disponible:true,  avatar:"🧑‍💻" },
  { id:4, nombre:"Pedro Díaz",     rol:"DevOps Eng",     nivel:"mid",    tech:["Docker","K8s","AWS"],      exp:5, rating:4.3, disponible:true,  avatar:"🧑‍🔧" },
  { id:5, nombre:"María López",    rol:"Mobile Dev",     nivel:"junior", tech:["React Native","Swift"],    exp:2, rating:4.1, disponible:false, avatar:"👩‍💻" },
  { id:6, nombre:"Carlos Ruiz",    rol:"Data Engineer",  nivel:"senior", tech:["Python","Spark","SQL"],    exp:9, rating:4.7, disponible:true,  avatar:"👨‍💻" },
  { id:7, nombre:"Valeria Torres", rol:"Frontend Dev",   nivel:"junior", tech:["Vue","CSS","JavaScript"],  exp:1, rating:3.9, disponible:true,  avatar:"🧑‍💻" },
  { id:8, nombre:"Diego Castillo", rol:"Backend Dev",    nivel:"mid",    tech:["Java","Spring","SQL"],     exp:4, rating:4.4, disponible:false, avatar:"👨‍💻" },
  { id:9, nombre:"Isabella Chen",  rol:"ML Engineer",    nivel:"senior", tech:["Python","TensorFlow","R"], exp:6, rating:4.6, disponible:true,  avatar:"👩‍💻" },
  { id:10,nombre:"Mateo Vargas",   rol:"Full Stack",     nivel:"junior", tech:["React","Node.js","CSS"],   exp:1, rating:4.0, disponible:true,  avatar:"🧑‍💻" },
  { id:11,nombre:"Sofía Mendez",   rol:"UX/UI Dev",      nivel:"mid",    tech:["CSS","Figma","JavaScript"],exp:3, rating:4.2, disponible:false, avatar:"👩‍🎨" },
  { id:12,nombre:"Andrés Rojas",   rol:"DevOps Eng",     nivel:"senior", tech:["AWS","Terraform","Python"],exp:10,rating:4.9, disponible:true,  avatar:"🧑‍🔧" },
];


// ── 2. ESTADO ────────────────────────────────────
// TU CÓDIGO AQUÍ
// let busqueda       = ''
// let filtroNivel    = ''
// let soloDisponible = false
// let ordenarPor     = 'nombre'


// ── 3. SELECCIÓN DE ELEMENTOS ────────────────────
// TU CÓDIGO AQUÍ


// ── 4. FUNCIÓN: filtrarYOrdenar() ────────────────
// Aplica todos los filtros activos sobre el array devs:
// 1. Filtro de texto: busca en nombre, rol y tech (case insensitive)
// 2. Filtro de nivel si filtroNivel !== ''
// 3. Filtro de disponible si soloDisponible
// 4. Ordena por el criterio activo
// Retorna el array filtrado y ordenado
function filtrarYOrdenar() {
  // TU CÓDIGO AQUÍ
}


// ── 5. FUNCIÓN: resaltarTexto(texto, busqueda) ───
// Si hay búsqueda activa, envuelve las coincidencias en <mark>
// Si no, retorna el texto sin cambios
function resaltarTexto(texto, busqueda) {
  // TU CÓDIGO AQUÍ
  // Pista: texto.replace(new RegExp(busqueda, 'gi'), m => `<mark>${m}</mark>`)
}


// ── 6. FUNCIÓN: crearCard(dev) ───────────────────
// Crea el HTML de una tarjeta de dev
// Resalta las tecnologías que coincidan con la búsqueda
function crearCard(dev) {
  // TU CÓDIGO AQUÍ
}


// ── 7. FUNCIÓN: renderizar() ─────────────────────
// Obtiene los devs filtrados, renderiza las cards
// Actualiza el contador de resultados
// Muestra/oculta el mensaje de "sin resultados"
function renderizar() {
  // TU CÓDIGO AQUÍ
}


// ── 8. EVENT LISTENERS ───────────────────────────

// Input de búsqueda → debounce de 200ms para no renderizar en cada tecla
// TU CÓDIGO AQUÍ

// Chips de nivel
// TU CÓDIGO AQUÍ

// Checkbox disponible
// TU CÓDIGO AQUÍ

// Select de ordenamiento
// TU CÓDIGO AQUÍ


// ── 9. INICIO ────────────────────────────────────
renderizar();


// ── 10. BONUS: debounce ───────────────────────────
// Implementa la función debounce y úsala en el input de búsqueda
function debounce(fn, ms) {
  // TU CÓDIGO AQUÍ
}
