# 06 · Buscador/Filtro — Pistas

## Pista 1 — Filtrar por texto
```js
const q = busqueda.toLowerCase();
const coincide = dev.nombre.toLowerCase().includes(q) ||
                 dev.rol.toLowerCase().includes(q)    ||
                 dev.tech.some(t => t.toLowerCase().includes(q));
```

## Pista 2 — Ordenar por distintos criterios
```js
resultados.sort((a, b) => {
  if (ordenarPor === 'nombre')       return a.nombre.localeCompare(b.nombre);
  if (ordenarPor === 'experiencia')  return b.exp - a.exp;
  if (ordenarPor === 'rating')       return b.rating - a.rating;
});
```

## Pista 3 — Resaltar coincidencias
```js
function resaltarTexto(texto, q) {
  if (!q) return texto;
  return texto.replace(new RegExp(q, 'gi'), m => `<mark>${m}</mark>`);
}
```
Aplícalo al nombre y al rol en la card. Para las tech, añade clase 'highlight' al chip si incluye la búsqueda.

## Pista 4 — Estrellas de rating
```js
const estrellas = '★'.repeat(Math.round(dev.rating)) + '☆'.repeat(5 - Math.round(dev.rating));
```
