# 08 · Juego de Memoria — Pistas

## Pista 1 — Crear y mezclar el tablero
```js
function crearTablero(size, pares) {
  // Tomar 'pares' emojis al azar
  const mezclados = [...EMOJIS].sort(() => Math.random() - 0.5).slice(0, pares);
  // Duplicar y crear objetos
  const cartas = [...mezclados, ...mezclados].map((emoji, i) => ({
    id: i, emoji, volteada: false, encontrada: false
  }));
  // Mezclar con Fisher-Yates
  for (let i = cartas.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cartas[i], cartas[j]] = [cartas[j], cartas[i]];
  }
  return cartas;
}
```

## Pista 2 — Estructura HTML de una carta
```html
<div class="card" data-id="5">
  <div class="card-inner">
    <div class="card-face card-back"></div>
    <div class="card-face card-front">🦊</div>
  </div>
</div>
```
Para voltear: `card.classList.add('flipped')`  
Para marcar como encontrada: `card.classList.add('matched')`

## Pista 3 — Lógica de comparación
```js
function manejarClick(id) {
  if (bloqueado) return;
  const carta = tablero.find(c => c.id === id);
  if (!carta || carta.encontrada || carta.volteada) return;
  carta.volteada = true;
  // voltear en el DOM
  if (!primeraCarta) {
    primeraCarta = carta;
    return;
  }
  segundaCarta = carta;
  movimientos++;
  bloqueado = true;
  actualizarHUD();
  if (primeraCarta.emoji === segundaCarta.emoji) {
    // Son iguales: marcar como encontradas
    primeraCarta.encontrada = segundaCarta.encontrada = true;
    paresEncontrados++;
    bloqueado = false;
    primeraCarta = segundaCarta = null;
    if (paresEncontrados === totalPares) ganar();
  } else {
    // No coinciden: esperar y voltear de nuevo
    setTimeout(() => {
      primeraCarta.volteada = segundaCarta.volteada = false;
      // actualizar DOM
      bloqueado = false;
      primeraCarta = segundaCarta = null;
    }, 1000);
  }
}
```

## Pista 4 — Event delegation en el board
```js
document.getElementById('board').addEventListener('click', (e) => {
  const card = e.target.closest('.card');
  if (!card) return;
  manejarClick(Number(card.dataset.id));
});
```
