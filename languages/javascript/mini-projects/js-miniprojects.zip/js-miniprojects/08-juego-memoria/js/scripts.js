// ════════════════════════════════════════════════
//  MINI PROYECTO 08 — Juego de Memoria
//  El más completo. Integra casi todo lo de basics.
// ════════════════════════════════════════════════

// ── 1. EMOJIS DISPONIBLES ────────────────────────
const EMOJIS = [
  '🦊','🐺','🦁','🐯','🐻','🐼','🐨','🦄',
  '🦋','🐉','🦅','🦩','🦚','🦜','🦞','🦑',
  '🍉','🍋','🍇','🍓','🥝','🍍','🥭','🍑',
  '⚡','🔥','❄️','🌊','🌈','☄️','🌀','💎',
];


// ── 2. ESTADO DEL JUEGO ──────────────────────────
// TU CÓDIGO AQUÍ
// let tablero      = []   ← array de objetos carta
// let primeraCarta = null
// let segundaCarta = null
// let bloqueado    = false  ← previene clicks durante animaciones
// let movimientos  = 0
// let paresEncontrados = 0
// let totalPares   = 0
// let timerInterval = null
// let segundos     = 0
// let tamanoBoard  = 4


// ── 3. FUNCIÓN: crearTablero(size, pares) ────────
// Selecciona `pares` emojis aleatorios del array EMOJIS
// Duplica cada uno (para crear los pares)
// Mezcla el array resultante (Fisher-Yates)
// Retorna array de objetos: { id, emoji, volteada, encontrada }
function crearTablero(size, pares) {
  // TU CÓDIGO AQUÍ
}


// ── 4. FUNCIÓN: renderTablero() ──────────────────
// Aplica la clase de tamaño al board (size-4, size-6, size-8)
// Genera el HTML de cada carta
// Cada carta tiene: div.card con data-id, dentro .card-inner > .card-back + .card-front
// El .card-front muestra el emoji
function renderTablero() {
  // TU CÓDIGO AQUÍ
}


// ── 5. FUNCIÓN: manejarClick(id) ─────────────────
// El corazón del juego. Se llama cuando el jugador hace click en una carta.
// Reglas:
// - Si bloqueado: ignorar
// - Si la carta ya está encontrada o ya está volteada: ignorar
// - Voltear la carta (agregar clase 'flipped')
// - Si es la primera: guardar como primeraCarta
// - Si es la segunda:
//   - Incrementar movimientos
//   - ¿Son iguales? → marcar como encontradas, incrementar paresEncontrados
//     → ¿Es el último par? → ganar
//   - ¿No son iguales? → después de 1s, voltear ambas de nuevo
//   - Bloquear durante la comparación, luego desbloquear
function manejarClick(id) {
  // TU CÓDIGO AQUÍ
}


// ── 6. FUNCIÓN: iniciarJuego(size, pares) ────────
// Resetea todo el estado
// Crea el tablero, lo renderiza
// Inicia el timer
// Muestra la pantalla de juego
function iniciarJuego(size, pares) {
  // TU CÓDIGO AQUÍ
}


// ── 7. FUNCIÓN: iniciarTimer() ────────────────────
// setInterval cada 1s, actualiza #hud-time con formato M:SS
function iniciarTimer() {
  // TU CÓDIGO AQUÍ
}


// ── 8. FUNCIÓN: detenerTimer() ────────────────────
function detenerTimer() {
  // TU CÓDIGO AQUÍ
}


// ── 9. FUNCIÓN: actualizarHUD() ──────────────────
// Actualiza #hud-moves y #hud-pairs con los valores actuales
function actualizarHUD() {
  // TU CÓDIGO AQUÍ
}


// ── 10. FUNCIÓN: ganar() ─────────────────────────
// Detiene el timer
// Calcula las estrellas según movimientos vs mínimo teórico
// Muestra la pantalla de victoria con las stats
function ganar() {
  // TU CÓDIGO AQUÍ
  // Mínimo teórico de movimientos = totalPares (si aciertas todos de primera)
  // 3 estrellas: movimientos <= totalPares * 1.5
  // 2 estrellas: movimientos <= totalPares * 2.5
  // 1 estrella:  más movimientos
}


// ── 11. FUNCIÓN: calcularEstrellas(movs, pares) ──
function calcularEstrellas(movs, pares) {
  // TU CÓDIGO AQUÍ
}


// ── 12. FUNCIÓN: formatearTiempo(s) ──────────────
// Convierte segundos a "M:SS"
function formatearTiempo(s) {
  // TU CÓDIGO AQUÍ
}


// ── 13. EVENT LISTENERS ──────────────────────────
// Botones de dificultad → iniciarJuego(size, pares)
// TU CÓDIGO AQUÍ

// Click en las cartas (event delegation en el board)
// TU CÓDIGO AQUÍ

// Botón menú del HUD → volver al menú (detener timer)
// TU CÓDIGO AQUÍ

// Botones de la pantalla de victoria
// TU CÓDIGO AQUÍ
