# 08 · Juego de Memoria

## ¿Qué construyes?
El clásico juego de memoria con 3 dificultades, timer, contador de movimientos y rating de estrellas.

## Resultado esperado
- Menú con 3 dificultades (4×4, 6×6, 8×8)
- Tablero de cartas que se voltean con animación CSS 3D
- Las cartas encontradas quedan visibles con color destacado
- HUD con: movimientos, pares encontrados / total, timer
- Pantalla de victoria con stats y rating ★★★
- Opción de jugar de nuevo (misma dificultad) o volver al menú

## Conceptos que practicas
- Arrays de objetos (el tablero)
- Algoritmo Fisher-Yates para mezclar
- Closures: el estado del juego encapsulado
- setTimeout para el delay de volteo
- setInterval para el timer
- Event delegation en el tablero
- Lógica de estado: bloqueado, primeraCarta, segundaCarta
- Clases CSS controladas por JS (flipped, matched)

## Criterios de éxito
- [ ] Las cartas se voltean con animación fluida (CSS transform)
- [ ] Solo se pueden voltear 2 cartas a la vez (el juego se bloquea)
- [ ] Si las 2 cartas coinciden, quedan en color amarillo
- [ ] Si no coinciden, se voltean de vuelta después de ~1 segundo
- [ ] El timer funciona y se detiene al ganar
- [ ] Los movimientos se cuentan correctamente
- [ ] Las estrellas reflejan la eficiencia del jugador
- [ ] Bonus: animación o efecto al completar el juego

## Archivos
- `js/scripts.js` — **aquí trabajas tú**
- `hints.md` — pistas si te trabas
