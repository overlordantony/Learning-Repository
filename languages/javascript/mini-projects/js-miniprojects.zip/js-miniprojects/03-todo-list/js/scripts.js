// ════════════════════════════════════════════════
//  MINI PROYECTO 03 — Lista de Tareas
//  Tu trabajo: implementar toda la lógica de JS
// ════════════════════════════════════════════════

// ── 1. ESTADO ────────────────────────────────────
// Carga las tareas desde localStorage si existen,
// si no, empieza con un array vacío.
// Cada tarea es un objeto: { id, texto, prioridad, completada, creadaEn }

// TU CÓDIGO AQUÍ
// let tareas = ...
// let filtroActivo = 'todas'
// let prioridadSeleccionada = 'normal'


// ── 2. SELECCIÓN DE ELEMENTOS ────────────────────
// TU CÓDIGO AQUÍ


// ── 3. FUNCIÓN: guardarEnStorage() ───────────────
// Serializa el array tareas y lo guarda en localStorage
// Clave sugerida: 'tasks-app'
function guardarEnStorage() {
  // TU CÓDIGO AQUÍ
}


// ── 4. FUNCIÓN: generarId() ───────────────────────
// Genera un ID único para cada tarea
// Pista: Date.now() + Math.random()
function generarId() {
  // TU CÓDIGO AQUÍ
}


// ── 5. FUNCIÓN: crearTarea(texto, prioridad) ─────
// Crea un objeto tarea nuevo, lo agrega al array,
// lo guarda en localStorage y rerenderiza la lista
function crearTarea(texto, prioridad) {
  // TU CÓDIGO AQUÍ
}


// ── 6. FUNCIÓN: toggleTarea(id) ──────────────────
// Cambia completada: false ↔ true para la tarea con ese id
// Guarda y rerenderiza
function toggleTarea(id) {
  // TU CÓDIGO AQUÍ
}


// ── 7. FUNCIÓN: eliminarTarea(id) ────────────────
// Elimina la tarea del array usando filter
// Guarda y rerenderiza
function eliminarTarea(id) {
  // TU CÓDIGO AQUÍ
}


// ── 8. FUNCIÓN: tareasVisibles() ─────────────────
// Retorna el subarray filtrado según filtroActivo
// 'todas' → todas, 'pendientes' → !completada, 'completadas' → completada
function tareasVisibles() {
  // TU CÓDIGO AQUÍ
}


// ── 9. FUNCIÓN: renderizar() ─────────────────────
// Renderiza la lista de tareas visibles en el DOM
// Para cada tarea, crear un elemento .task-item con:
//   - checkbox (.task-check) con ✓ si está completada
//   - texto (.task-text)
//   - badge de prioridad si no es 'normal'
//   - botón de eliminar (.task-delete) con ×
// Si no hay tareas visibles, mostrar #empty-state
// Actualizar contadores: #stat-pending, #footer-count
function renderizar() {
  // TU CÓDIGO AQUÍ
}


// ── 10. FUNCIÓN: actualizarFecha() ───────────────
// Muestra la fecha actual en #date-chip
// Formato: "lunes, 6 ene"
function actualizarFecha() {
  // TU CÓDIGO AQUÍ
  // Pista: new Date() + Intl.DateTimeFormat o toLocaleDateString()
}


// ── 11. EVENT LISTENERS ──────────────────────────

// Botón agregar + Enter en el input
// TU CÓDIGO AQUÍ

// Selector de prioridad (botones .pri-btn)
// Al hacer click: quitar 'active' de todos, agregar al clickeado
// Actualizar prioridadSeleccionada
// TU CÓDIGO AQUÍ

// Filtros (.filter-btn)
// TU CÓDIGO AQUÍ

// Limpiar completadas (#btn-clear-done)
// TU CÓDIGO AQUÍ

// Borrar todo (#btn-clear-all)
// Pide confirmación antes: confirm("¿Borrar todas las tareas?")
// TU CÓDIGO AQUÍ

// Delegación en la lista para clicks en checkbox y botón delete
// Pista: e.target.closest('.task-check') o e.target.closest('.task-delete')
// TU CÓDIGO AQUÍ


// ── 12. INICIO ───────────────────────────────────
actualizarFecha();
renderizar();
