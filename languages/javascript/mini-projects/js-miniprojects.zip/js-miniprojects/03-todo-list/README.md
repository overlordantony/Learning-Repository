# 03 · Lista de Tareas

## ¿Qué construyes?
Una app de gestión de tareas con prioridades, filtros y persistencia en localStorage.

## Resultado esperado
- Agregar tareas con texto y prioridad (normal / alta / baja)
- Marcar tareas como completadas (toggle)
- Eliminar tareas individuales
- Filtrar por: todas / pendientes / completadas
- Limpiar todas las completadas de una vez
- Las tareas persisten al recargar la página (localStorage)
- Contador de tareas pendientes en el header

## Conceptos que practicas
- Arrays de objetos (CRUD completo)
- localStorage (persistencia)
- Generación dinámica de elementos DOM
- Event delegation para la lista
- Filtrado con filter()
- Estado coordinado (filtro activo, prioridad seleccionada)

## Criterios de éxito
- [ ] Agregar tarea con Enter o botón
- [ ] No se puede agregar una tarea vacía
- [ ] El checkbox marca/desmarca la tarea con animación
- [ ] El botón × elimina la tarea
- [ ] Los 3 filtros funcionan correctamente
- [ ] "Limpiar ✓" elimina solo las completadas
- [ ] "Borrar todo" pide confirmación y limpia todo
- [ ] Al recargar la página, las tareas siguen ahí
- [ ] El contador de pendientes es siempre correcto

## Archivos
- `js/scripts.js` — **aquí trabajas tú**
- `hints.md` — pistas si te trabas
