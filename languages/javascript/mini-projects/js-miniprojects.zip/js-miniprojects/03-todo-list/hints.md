# 03 · Todo List — Pistas

## Pista 1 — Estructura de una tarea
```js
{
  id: 1704567890123,
  texto: "Aprender closures",
  prioridad: "alta",
  completada: false,
  creadaEn: "2025-01-06T10:30:00.000Z"
}
```

## Pista 2 — Cargar desde localStorage
```js
let tareas = JSON.parse(localStorage.getItem('tasks-app')) ?? [];
```

## Pista 3 — Crear elemento de tarea
```js
function crearElementoTarea(tarea) {
  const div = document.createElement('div');
  div.className = `task-item${tarea.completada ? ' done' : ''}`;
  div.dataset.id = tarea.id;
  div.innerHTML = `
    <div class="task-check">${tarea.completada ? '✓' : ''}</div>
    <div class="task-content">
      <div class="task-text">${tarea.texto}</div>
      ${tarea.prioridad !== 'normal' ? `<span class="task-badge badge-${tarea.prioridad}">${tarea.prioridad.toUpperCase()}</span>` : ''}
    </div>
    <button class="task-delete">×</button>
  `;
  return div;
}
```

## Pista 4 — Event delegation en la lista
```js
taskList.addEventListener('click', (e) => {
  const item  = e.target.closest('.task-item');
  if (!item) return;
  const id = Number(item.dataset.id);

  if (e.target.closest('.task-check'))  toggleTarea(id);
  if (e.target.closest('.task-delete')) eliminarTarea(id);
});
```

## Pista 5 — Fecha actual
```js
function actualizarFecha() {
  const fecha = new Date().toLocaleDateString('es-ES', {
    weekday: 'long', day: 'numeric', month: 'short'
  });
  document.getElementById('date-chip').textContent = fecha;
}
```
