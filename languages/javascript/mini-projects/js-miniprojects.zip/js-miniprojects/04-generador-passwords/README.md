# 04 · Generador de Contraseñas

## ¿Qué construyes?
Un generador de contraseñas con opciones configurables, medidor de fortaleza e historial.

## Resultado esperado
- Deslizador de longitud (6-64 caracteres)
- Checkboxes para: mayúsculas, minúsculas, números, símbolos, excluir ambiguos
- Contraseña generada en una caja monoespaciada con botón para copiar
- Barra de fortaleza con colores: rojo/naranja/azul/verde
- Historial de las últimas 8 contraseñas generadas (click para copiar)

## Conceptos que practicas
- Strings (construir y manipular conjuntos de caracteres)
- Math.random() para selección aleatoria
- Arrays como historial con límite de tamaño
- Lectura de múltiples inputs del formulario
- Clipboard API (navigator.clipboard)
- Feedback visual con setTimeout

## Criterios de éxito
- [ ] No se puede generar con todos los checkboxes desmarcados
- [ ] La contraseña siempre contiene al menos un carácter de cada tipo activado
- [ ] La longitud del deslizador se refleja en tiempo real
- [ ] El botón copiar da feedback visual ("✓ Copiado")
- [ ] La barra de fortaleza cambia de color y tamaño correctamente
- [ ] El historial no supera 8 entradas
- [ ] Bonus: garantizar que la contraseña contenga al menos 1 carácter de cada tipo activo

## Archivos
- `js/scripts.js` — **aquí trabajas tú**
- `hints.md` — pistas si te trabas
