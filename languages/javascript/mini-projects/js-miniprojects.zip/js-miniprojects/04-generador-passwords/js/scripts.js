// ════════════════════════════════════════════════
//  MINI PROYECTO 04 — Generador de Contraseñas
// ════════════════════════════════════════════════

// ── 1. CONJUNTOS DE CARACTERES ───────────────────
const CHARS = {
  upper:   'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
  lower:   'abcdefghijklmnopqrstuvwxyz',
  numbers: '0123456789',
  symbols: '!@#$%^&*()_+-=[]{}|;:,.<>?',
  ambiguous: '0O1lI', // a excluir si está activada la opción
};


// ── 2. SELECCIÓN DE ELEMENTOS ────────────────────
// TU CÓDIGO AQUÍ


// ── 3. FUNCIÓN: construirCharset() ───────────────
// Lee los checkboxes y construye el string de caracteres disponibles
// Si "excluir ambiguos" está activado, elimínalos del charset
// Si no queda ningún tipo seleccionado, retorna al menos minúsculas
function construirCharset() {
  // TU CÓDIGO AQUÍ
}


// ── 4. FUNCIÓN: generarPassword(longitud, charset) ─
// Genera un string aleatorio de longitud dada usando el charset
// Asegura que al menos un carácter de cada tipo habilitado esté presente
function generarPassword(longitud, charset) {
  // TU CÓDIGO AQUÍ
  // Pista básica: Array.from({length}, () => charset[Math.floor(Math.random()*charset.length)]).join('')
  // Bonus: garantizar al menos un carácter de cada grupo activo
}


// ── 5. FUNCIÓN: calcularFortaleza(password) ──────
// Retorna objeto { nivel: 'débil'|'regular'|'buena'|'fuerte', pct: 0-100, color }
// Criterios sugeridos: longitud, tipos de caracteres usados, entropía
function calcularFortaleza(password) {
  // TU CÓDIGO AQUÍ
}


// ── 6. FUNCIÓN: actualizarFortaleza(password) ────
// Actualiza la barra y el label de fortaleza en el DOM
function actualizarFortaleza(password) {
  // TU CÓDIGO AQUÍ
}


// ── 7. FUNCIÓN: copiarAlPortapapeles() ───────────
// Copia la contraseña actual al clipboard
// Muestra feedback visual en el botón ("Copiado ✓")
async function copiarAlPortapapeles() {
  // TU CÓDIGO AQUÍ
  // Pista: navigator.clipboard.writeText(texto)
  // Cambiar el botón temporalmente y restaurarlo
}


// ── 8. FUNCIÓN: agregarAlHistorial(password) ─────
// Agrega la contraseña al inicio del historial (máximo 8)
// Al hacer click en una entrada del historial, copiarla
function agregarAlHistorial(password) {
  // TU CÓDIGO AQUÍ
}


// ── 9. FUNCIÓN: renderHistorial() ────────────────
// Renderiza el array historial en #history-list
function renderHistorial() {
  // TU CÓDIGO AQUÍ
}


// ── 10. FUNCIÓN: generar() ───────────────────────
// Función principal: lee todas las opciones, genera, muestra y guarda
function generar() {
  // TU CÓDIGO AQUÍ
}


// ── 11. EVENT LISTENERS ──────────────────────────
// Range de longitud → actualizar el número mostrado en tiempo real
// TU CÓDIGO AQUÍ

// Botón generar
// TU CÓDIGO AQUÍ

// Botón copiar
// TU CÓDIGO AQUÍ

// Limpiar historial
// TU CÓDIGO AQUÍ

// Generar automáticamente al cargar la página
// TU CÓDIGO AQUÍ
