# 04 · Generador de Contraseñas — Pistas

## Pista 1 — Construir charset
```js
function construirCharset() {
  let charset = '';
  if (document.getElementById('chk-upper').checked)   charset += CHARS.upper;
  if (document.getElementById('chk-lower').checked)   charset += CHARS.lower;
  if (document.getElementById('chk-numbers').checked) charset += CHARS.numbers;
  if (document.getElementById('chk-symbols').checked) charset += CHARS.symbols;
  if (!charset) charset = CHARS.lower; // fallback
  if (document.getElementById('chk-exclude-ambiguous').checked) {
    charset = charset.split('').filter(c => !CHARS.ambiguous.includes(c)).join('');
  }
  return charset;
}
```

## Pista 2 — Generar password básico
```js
const charset = construirCharset();
const password = Array.from(
  { length: longitud },
  () => charset[Math.floor(Math.random() * charset.length)]
).join('');
```

## Pista 3 — Garantizar al menos un carácter de cada tipo
```js
// Construir el pool de "garantizados"
const garantizados = [];
if (chkUpper.checked)   garantizados.push(elegirRandom(CHARS.upper));
if (chkLower.checked)   garantizados.push(elegirRandom(CHARS.lower));
// ... etc
// Rellenar el resto hasta alcanzar la longitud
const resto = longitud - garantizados.length;
// ... rellenar con charset random
// Mezclar con Fisher-Yates para que los garantizados no vayan siempre al inicio
```

## Pista 4 — Fortaleza por puntos
```js
let puntos = 0;
if (password.length >= 12) puntos++;
if (password.length >= 20) puntos++;
if (/[A-Z]/.test(password)) puntos++;
if (/[a-z]/.test(password)) puntos++;
if (/[0-9]/.test(password)) puntos++;
if (/[^A-Za-z0-9]/.test(password)) puntos++;
// 0-1: débil, 2-3: regular, 4-5: buena, 6: fuerte
```

## Pista 5 — Copiar al portapapeles
```js
async function copiarAlPortapapeles() {
  const texto = document.getElementById('password-text').textContent;
  await navigator.clipboard.writeText(texto);
  btnCopy.textContent = '✓';
  btnCopy.classList.add('copied');
  setTimeout(() => {
    btnCopy.textContent = '⎘';
    btnCopy.classList.remove('copied');
  }, 1500);
}
```
