// ════════════════════════════════════════════════
//  MINI PROYECTO 07 — Conversor de Unidades
// ════════════════════════════════════════════════

// ── 1. DEFINICIÓN DE UNIDADES ────────────────────
// Cada categoría tiene unidades con un factor de conversión a la unidad base.
// Para temperatura se usa una función especial (no es multiplicación lineal).

const UNIDADES = {
  longitud: {
    label: "Longitud",
    base: "metro",
    unidades: {
      "Kilómetro":  { simbolo:"km",   factor:1000 },
      "Metro":      { simbolo:"m",    factor:1 },
      "Centímetro": { simbolo:"cm",   factor:0.01 },
      "Milímetro":  { simbolo:"mm",   factor:0.001 },
      "Milla":      { simbolo:"mi",   factor:1609.34 },
      "Yarda":      { simbolo:"yd",   factor:0.9144 },
      "Pie":        { simbolo:"ft",   factor:0.3048 },
      "Pulgada":    { simbolo:"in",   factor:0.0254 },
      "Milla náut.":{ simbolo:"nmi",  factor:1852 },
    }
  },
  masa: {
    label: "Masa",
    base: "kilogramo",
    unidades: {
      "Tonelada":   { simbolo:"t",   factor:1000 },
      "Kilogramo":  { simbolo:"kg",  factor:1 },
      "Gramo":      { simbolo:"g",   factor:0.001 },
      "Miligramo":  { simbolo:"mg",  factor:0.000001 },
      "Libra":      { simbolo:"lb",  factor:0.453592 },
      "Onza":       { simbolo:"oz",  factor:0.0283495 },
    }
  },
  temperatura: {
    label: "Temperatura",
    base: "celsius",
    especial: true, // usa funciones de conversión, no factor
    unidades: {
      "Celsius":    { simbolo:"°C" },
      "Fahrenheit": { simbolo:"°F" },
      "Kelvin":     { simbolo:"K" },
    }
  },
  velocidad: {
    label: "Velocidad",
    base: "m/s",
    unidades: {
      "m/s":        { simbolo:"m/s",  factor:1 },
      "km/h":       { simbolo:"km/h", factor:1/3.6 },
      "mph":        { simbolo:"mph",  factor:0.44704 },
      "Nudo":       { simbolo:"kn",   factor:0.514444 },
      "Mach":       { simbolo:"Ma",   factor:343 },
    }
  },
  area: {
    label: "Área",
    base: "metro²",
    unidades: {
      "km²":        { simbolo:"km²",  factor:1e6 },
      "Metro²":     { simbolo:"m²",   factor:1 },
      "Centímetro²":{ simbolo:"cm²",  factor:0.0001 },
      "Hectárea":   { simbolo:"ha",   factor:10000 },
      "Acre":       { simbolo:"ac",   factor:4046.86 },
      "Milla²":     { simbolo:"mi²",  factor:2589988 },
      "Pie²":       { simbolo:"ft²",  factor:0.092903 },
      "Pulgada²":   { simbolo:"in²",  factor:0.00064516 },
    }
  },
  almacenamiento: {
    label: "Almacenamiento",
    base: "byte",
    unidades: {
      "Bit":        { simbolo:"b",   factor:0.125 },
      "Byte":       { simbolo:"B",   factor:1 },
      "Kilobyte":   { simbolo:"KB",  factor:1024 },
      "Megabyte":   { simbolo:"MB",  factor:1048576 },
      "Gigabyte":   { simbolo:"GB",  factor:1073741824 },
      "Terabyte":   { simbolo:"TB",  factor:1.0995e12 },
    }
  }
};


// ── 2. ESTADO ────────────────────────────────────
// TU CÓDIGO AQUÍ
// let categoriaActiva = 'longitud'


// ── 3. SELECCIÓN DE ELEMENTOS ────────────────────
// TU CÓDIGO AQUÍ


// ── 4. FUNCIÓN: convertir(valor, desde, hasta, categoria) ───
// Convierte un valor de una unidad a otra
// Para categorías normales: valor * factorDesde / factorHasta
// Para temperatura: usar las fórmulas específicas
function convertir(valor, desde, hasta, categoria) {
  // TU CÓDIGO AQUÍ
  // Para temperatura, las fórmulas son:
  // C→F: (C * 9/5) + 32
  // C→K: C + 273.15
  // F→C: (F - 32) * 5/9
  // F→K: (F - 32) * 5/9 + 273.15
  // K→C: K - 273.15
  // K→F: (K - 273.15) * 9/5 + 32
}


// ── 5. FUNCIÓN: poblarSelects(categoria) ─────────
// Llena los <select> con las unidades de la categoría activa
// Mantiene las selecciones anteriores si son válidas para la nueva categoría
function poblarSelects(categoria) {
  // TU CÓDIGO AQUÍ
}


// ── 6. FUNCIÓN: calcularYMostrar() ───────────────
// Lee valor, unidad de origen y destino
// Llama a convertir(), muestra el resultado en #to-value y #result-big
// Actualiza la fórmula descriptiva en #formula-display
function calcularYMostrar() {
  // TU CÓDIGO AQUÍ
}


// ── 7. FUNCIÓN: actualizarTablaReferencia() ───────
// Genera la tabla de referencia: convierte 1 unidad de origen a todas las demás
function actualizarTablaReferencia() {
  // TU CÓDIGO AQUÍ
}


// ── 8. FUNCIÓN: formatearNumero(n) ───────────────
// Formatea el número para mostrarlo legiblemente:
// Si es muy grande o muy pequeño, usa notación científica
// Si tiene muchos decimales, redondea a 8
function formatearNumero(n) {
  // TU CÓDIGO AQUÍ
}


// ── 9. EVENT LISTENERS ───────────────────────────
// Tabs de categoría
// Inputs (from-value, from-unit, to-unit)
// Botón swap: intercambia las dos unidades
// TU CÓDIGO AQUÍ


// ── 10. INICIO ───────────────────────────────────
// Cargar la categoría inicial
// TU CÓDIGO AQUÍ
