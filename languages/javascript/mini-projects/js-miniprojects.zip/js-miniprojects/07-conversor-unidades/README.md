# 07 · Conversor de Unidades

## ¿Qué construyes?
Un conversor de unidades con 6 categorías y tabla de referencia.

## Resultado esperado
- 6 categorías: longitud, masa, temperatura, velocidad, área, almacenamiento
- Dos selectores (de/a) que se llenan con las unidades de la categoría
- El resultado se actualiza en tiempo real mientras escribes
- Tabla de referencia que muestra 1 unidad en todas las demás
- Botón para intercambiar unidades (⇅)
- Temperatura con conversiones especiales (no lineales)

## Conceptos que practicas
- Objetos anidados (la estructura UNIDADES)
- switch para casos especiales (temperatura)
- Poblar `<select>` dinámicamente con JS
- Aritmética de conversión con factores
- Formatear números (toFixed, toExponential, toLocaleString)
- Actualización reactiva del DOM

## Criterios de éxito
- [ ] Todas las categorías se cargan correctamente en los selects
- [ ] Las conversiones de factor son precisas
- [ ] Las conversiones de temperatura son correctas (probar: 100°C = 212°F = 373.15K)
- [ ] El botón ⇅ intercambia las unidades (y recalcula)
- [ ] La tabla de referencia se actualiza al cambiar la unidad de origen
- [ ] Los números grandes/pequeños se formatean legiblemente
- [ ] Bonus: conversión bidireccional (editar el campo de resultado actualiza el origen)

## Archivos
- `js/scripts.js` — **aquí trabajas tú**
- `hints.md` — pistas si te trabas
