# 07 · Conversor — Pistas

## Pista 1 — Conversión con factor
```js
// Primero convertir a la unidad base, luego a la destino
function convertir(valor, desde, hasta, categoria) {
  const cat = UNIDADES[categoria];
  if (cat.especial) { /* temperatura */ return convertirTemp(valor, desde, hasta); }
  const factorDesde = cat.unidades[desde].factor;
  const factorHasta = cat.unidades[hasta].factor;
  return valor * factorDesde / factorHasta;
}
```

## Pista 2 — Poblar selects
```js
function poblarSelects(categoria) {
  const unidades = Object.keys(UNIDADES[categoria].unidades);
  [fromUnit, toUnit].forEach((sel, i) => {
    const prevVal = sel.value;
    sel.innerHTML = '';
    unidades.forEach(u => {
      const opt = document.createElement('option');
      opt.value = u;
      opt.textContent = `${u} (${UNIDADES[categoria].unidades[u].simbolo})`;
      sel.appendChild(opt);
    });
    // Restaurar valor previo si sigue siendo válido
    if (unidades.includes(prevVal)) sel.value = prevVal;
    else sel.value = unidades[i]; // fallback a diferente unidad
  });
}
```

## Pista 3 — Formatear números
```js
function formatearNumero(n) {
  if (isNaN(n) || !isFinite(n)) return '—';
  if (Math.abs(n) >= 1e15 || (Math.abs(n) < 1e-6 && n !== 0)) {
    return n.toExponential(4);
  }
  return parseFloat(n.toFixed(8)).toLocaleString('es');
}
```
