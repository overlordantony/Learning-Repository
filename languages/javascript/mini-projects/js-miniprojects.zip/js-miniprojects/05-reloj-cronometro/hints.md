# 05 · Reloj/Cronómetro/Timer — Pistas

## Pista 1 — Reloj básico
```js
function actualizarReloj() {
  const ahora = new Date();
  const h = String(ahora.getHours()).padStart(2,'0');
  const m = String(ahora.getMinutes()).padStart(2,'0');
  const s = String(ahora.getSeconds()).padStart(2,'0');
  document.getElementById('clock-time').textContent = `${h}:${m}:${s}`;
}
setInterval(actualizarReloj, 1000);
actualizarReloj();
```

## Pista 2 — Anillos SVG (stroke-dashoffset)
```js
const circH = 2 * Math.PI * 54; // ~339.3
const fracH = (ahora.getHours() % 12) / 12;
document.getElementById('ring-hours').style.strokeDashoffset = circH * (1 - fracH);
// Repetir para minutos (radio 44, circunf ~276.5) y segundos (radio 34, ~213.6)
```

## Pista 3 — Cronómetro con setInterval
```js
function toggleCronometro() {
  if (swRunning) {
    clearInterval(swInterval);
    swRunning = false;
    btnStart.textContent = '▶ Continuar';
  } else {
    const inicio = Date.now() - swMs;
    swInterval = setInterval(() => {
      swMs = Date.now() - inicio;
      document.getElementById('sw-time').innerHTML =
        formatearTiempo(swMs).replace('.', '<span class="sw-ms">.') + '</span>';
    }, 10);
    swRunning = true;
    btnStart.textContent = '⏸ Pausar';
  }
}
```

## Pista 4 — Mejor y peor vuelta
```js
function renderVueltas() {
  const deltas = swLaps.map(l => l.delta);
  const mejor  = Math.min(...deltas);
  const peor   = Math.max(...deltas);
  // En el HTML de cada lap: añadir clase 'lap-best' si l.delta === mejor
}
```

## Pista 5 — Barra de progreso del timer
```js
const pct = (timerRestante / timerTotal) * 100;
document.getElementById('timer-bar').style.width = pct + '%';
```
