// ════════════════════════════════════════════════
//  MINI PROYECTO 05 — Reloj, Cronómetro y Timer
//  3 herramientas en una. Cada una usa setInterval.
// ════════════════════════════════════════════════

// ══ MÓDULO 1: RELOJ ══════════════════════════════

// ── 1. FUNCIÓN: actualizarReloj() ────────────────
// Lee la hora actual con new Date()
// Actualiza: #clock-time (HH:MM:SS), #clock-date, #clock-zone
// Actualiza los anillos SVG de horas, minutos y segundos
// Los anillos usan stroke-dashoffset para mostrar el progreso circular
function actualizarReloj() {
  // TU CÓDIGO AQUÍ
  // Pista para los anillos:
  // Circunferencia del radio 54 = 2*PI*54 = ~339.3
  // offset = circunferencia * (1 - fracción)
  // fracción de horas = (h % 12) / 12
  // fracción de minutos = m / 60
  // fracción de segundos = s / 60
}

// Iniciar el reloj
// TU CÓDIGO AQUÍ


// ══ MÓDULO 2: CRONÓMETRO ═════════════════════════

// ── 2. ESTADO DEL CRONÓMETRO ─────────────────────
// TU CÓDIGO AQUÍ
// let swInterval = null
// let swRunning  = false
// let swMs       = 0    ← milisegundos acumulados
// let swLaps     = []
// let swLapStart = 0    ← ms al inicio de la vuelta actual


// ── 3. FUNCIÓN: formatearTiempo(ms) ──────────────
// Convierte ms a "MM:SS.cc" (cc = centésimas)
function formatearTiempo(ms) {
  // TU CÓDIGO AQUÍ
  // const mins  = Math.floor(ms / 60000)
  // const secs  = Math.floor((ms % 60000) / 1000)
  // const cents = Math.floor((ms % 1000) / 10)
}


// ── 4. FUNCIÓN: toggleCronometro() ───────────────
// Si está corriendo: pausar (clearInterval, cambiar botón a "▶ Continuar")
// Si está pausado:   reanudar (setInterval cada 10ms, actualizar display)
function toggleCronometro() {
  // TU CÓDIGO AQUÍ
}


// ── 5. FUNCIÓN: vuelta() ─────────────────────────
// Registra el tiempo de la vuelta actual
// Calcula el tiempo parcial (desde la última vuelta)
// Agrega al array swLaps y renderiza
function vuelta() {
  // TU CÓDIGO AQUÍ
}


// ── 6. FUNCIÓN: resetCronometro() ────────────────
// Detiene todo, resetea el estado, limpia la lista de vueltas
function resetCronometro() {
  // TU CÓDIGO AQUÍ
}


// ── 7. FUNCIÓN: renderVueltas() ──────────────────
// Renderiza las vueltas en #laps-list
// La vuelta más rápida tiene clase 'lap-best', la más lenta 'lap-worst'
// Muestra: número de vuelta, tiempo acumulado, tiempo parcial (delta)
function renderVueltas() {
  // TU CÓDIGO AQUÍ
}


// ══ MÓDULO 3: TIMER ══════════════════════════════

// ── 8. ESTADO DEL TIMER ──────────────────────────
// TU CÓDIGO AQUÍ
// let timerInterval = null
// let timerTotal    = 0   ← segundos totales configurados
// let timerRestante = 0   ← segundos restantes


// ── 9. FUNCIÓN: iniciarTimer() ───────────────────
// Lee los inputs h/m/s
// Calcula el total en segundos (h*3600 + m*60 + s)
// Si total === 0, no hacer nada
// Muestra el panel de running, oculta el de setup
function iniciarTimer() {
  // TU CÓDIGO AQUÍ
}


// ── 10. FUNCIÓN: tickTimer() ─────────────────────
// Se ejecuta cada segundo
// Decrementa timerRestante
// Actualiza el display y la barra de progreso
// Si llega a 0: mostrar pantalla "done", reproducir sonido (opcional)
function tickTimer() {
  // TU CÓDIGO AQUÍ
}


// ── 11. FUNCIÓN: formatearTimer(segundos) ────────
// Convierte segundos a "HH:MM:SS" o "MM:SS"
function formatearTimer(s) {
  // TU CÓDIGO AQUÍ
}


// ── 12. FUNCIÓN: pausarTimer() / detenerTimer() ──
function pausarTimer() {
  // TU CÓDIGO AQUÍ
}
function detenerTimer() {
  // TU CÓDIGO AQUÍ
}


// ══ TABS ════════════════════════════════════════

// ── 13. Cambio de pestañas ────────────────────────
// Al hacer click en una tab: activarla y mostrar su panel
// Ocultar los demás paneles
// TU CÓDIGO AQUÍ


// ── 14. EVENT LISTENERS ──────────────────────────
// Cronómetro: start/pause, vuelta, reset
// Timer: iniciar, pausar, detener, "otro timer"
// TU CÓDIGO AQUÍ
