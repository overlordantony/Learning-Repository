# 05 · Reloj, Cronómetro y Timer

## ¿Qué construyes?
Tres herramientas de tiempo en una interfaz con pestañas.

## Resultado esperado
**Reloj:** hora actual en tiempo real con anillos SVG animados para H/M/S  
**Cronómetro:** iniciar/pausar/vuelta/reset, lista de vueltas con mejor y peor marcados  
**Timer:** configurar H:M:S, barra de progreso, alerta al llegar a cero

## Conceptos que practicas
- `setInterval` / `clearInterval` (el corazón de todo)
- `new Date()` y aritmética de tiempo
- Closures: cada módulo mantiene su propio estado
- Manipulación del DOM en tiempo real
- SVG: `stroke-dashoffset` para anillos de progreso
- Mostrar/ocultar secciones (tabs + estados del timer)

## Criterios de éxito
- [ ] El reloj se actualiza cada segundo y muestra hora/fecha/zona correctas
- [ ] Los anillos SVG reflejan el progreso de H, M y S
- [ ] El cronómetro inicia, pausa y reanuda correctamente
- [ ] Las vueltas se registran y la mejor/peor tienen colores distintos
- [ ] El timer cuenta hacia atrás hasta cero
- [ ] La barra de progreso del timer se reduce proporcionalmente
- [ ] Al llegar a cero, el timer muestra la pantalla de "¡Tiempo!"
- [ ] Bonus: sonido al terminar el timer (Web Audio API o Audio)

## Archivos
- `js/scripts.js` — **aquí trabajas tú**
- `hints.md` — pistas si te trabas
